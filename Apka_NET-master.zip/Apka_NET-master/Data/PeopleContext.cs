﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Apka_NET.Models;
namespace Apka_NET.Data
{
    public class PeopleContext : DbContext
    {
        public DbSet<Address> Address { get; set; }
        public PeopleContext(DbContextOptions options): base(options) { }
    }
}
