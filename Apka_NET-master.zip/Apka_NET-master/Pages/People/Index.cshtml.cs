﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Apka_NET.Data;
using Apka_NET.Models;

namespace Apka_NET.Pages.People
{
    public class IndexModel : PageModel
    {
        private readonly Apka_NET.Data.PeopleContext _context;

        public IndexModel(Apka_NET.Data.PeopleContext context)
        {
            _context = context;
        }

        public IList<Address> Address { get;set; }
        public void OnGet()
        {
            Address = _context.Address.OrderByDescending(u => u.SystemTime).Take(10).ToList();
        }

        /*   public async Task OnGetAsync()
           {
               Address = await _context.Address.ToListAsync();
           }*/
    }
}
